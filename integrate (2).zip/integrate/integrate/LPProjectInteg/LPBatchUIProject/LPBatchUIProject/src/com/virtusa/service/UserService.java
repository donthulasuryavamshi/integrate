package com.virtusa.service;

import com.virtusa.model.UserModel;

public interface UserService {

	boolean userAuthenticationService(UserModel userModel);

}
